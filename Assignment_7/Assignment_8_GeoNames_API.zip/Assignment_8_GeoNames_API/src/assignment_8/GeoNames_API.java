package assignment_8;


import java.text.DecimalFormat;

import javax.swing.JOptionPane;

import org.geonames.WeatherObservation;
import org.geonames.WebService;

/**
 * @author Kevin A. Medina
 *
 */
public class GeoNames_API {

	/**
	 * @param args -None
	 */
	public static void main(String[] args) 
	{
		//connect to web service client  
		WebService.setUserName(""); //enter user name here
		
		WeatherObservation weatherResult = new WeatherObservation();
		//Ft.Lauderdale - KFLL
		//Miami - KMIA
		//Chicago - KMDW
		//New York- KJFK
		//Los Angeles -KLAX
		//Montreal,CA - CYHU
		//Acapulco,MX - MMAA
		//Bogota,CO - SKBO
		//Moscow,RU - UUDD
		
		
		DecimalFormat df = new DecimalFormat("###.###");
		
		while(true)
		{
			String icaoCode = JOptionPane.showInputDialog("Enter ICAO Code").toUpperCase();
			
			try 
			{
				weatherResult = WebService.weatherIcao(icaoCode);
				System.out.println("***** ICAO CODE DETAILS *****");
				System.out.println("Station Name:\t"+weatherResult.getStationName());
				System.out.println("Country Code:\t"+weatherResult.getCountryCode());
				System.out.println("Latitude: "+df.format(weatherResult.getLatitude())+
								   " Longtitude: "+df.format(weatherResult.getLongitude()));
				System.out.println("\n***** WEATHER DETAILS*****");
				System.out.println("Time:\t\t"+weatherResult.getObservationTime().toString());
				System.out.println("Clouds:\t\t"+weatherResult.getClouds().toString());
				System.out.println("Temperature:\t"+df.format(weatherResult.getTemperature())+" C");
				System.out.println("Humididty:\t"+weatherResult.getHumidity()+" %");
				System.out.println("Wind Speed:\t"+weatherResult.getWindSpeed().toString()+" mph");
				System.out.println("Dew Point:\t"+weatherResult.getDewPoint()+" C\n");
			} catch (Exception e) 
			{
				System.out.println("ICAO Code Not Found");
			}
		}
	}//end main

}//end class
